<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>dashboard</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <header>
        <div class="Container">
        <h1><a href="dashboard.php">Penjualan Alat Olahraga</a></h1>
        <ul>
            <li><a href="dashboard.php">Dashboard</a><li>
                <li><a href="kategori.php">Data Kategori</a></li>
                <li><a href="produk.php">Data Produk</a><li>
                <li><a href="logout.php">Keluar</a><li>
</ul>
</ul>
</header>
<div class="section">
    <div class="Container">
        <h3>Dashboard</h3>
        <div class="box">
            <h4>Selamat Datang</h4>
            <br>
            <img src="5.jpg" height="400px" width="500px;">
            <img src="4.jpg" height="400px" width="500px;" align="left">
            <img src="8.jpg" height="400px" width="500px;">
            <img src="7.jpg" height="400px" width="500px;" align="left">




</div>
        </div>
</div>
</body>
</html>