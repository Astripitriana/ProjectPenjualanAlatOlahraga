<?php


   $host = "localhost";
    $database = "p_alatolahraga";
    $username = "root";
    $password = "";
    $connect = mysqli_connect($host, $username, $password, $database);

?>

